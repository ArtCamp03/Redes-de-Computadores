import socket

client_sock = socket.socket(socket.AF_INET , socket.SOCK_STREAM)

try:
    client_sock.connect(('127.0.0.1', 5050))
    print('conexao estabelecida \n')
    msg = ('Unicode')
    client_sock.sendall(str.encode(msg))
    resp = client_sock.recv(2048)
    print('resposta: ',resp.decode())
    msg = input('digite uma opcao: \n')
    client_sock.sendall(str.encode(msg))
    while resp:
        resp = client_sock.recv(2048)
        if resp:
            print('resposta: '+resp.decode()+'\n')
except socket.timeout:
    print('tempo esgotado')