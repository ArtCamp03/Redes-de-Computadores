import socket
from unicode import Unicode

code = Unicode()

# utilizei protocolo TCP pela confiabilidade no recebimento e entraga de dados e achei qe seria divertido implementar isso.
server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_sock.bind(('', 5050))
print('Servidor associado a porta:', server_sock.getsockname()[1])
server_sock.listen()
while True:
    conexao_sock, endereco = server_sock.accept()
    #conexao_sock.settimeout(10)
    print('conexao com ',endereco)
    resp = '\nOpcoes disponiveis: \nLC- Lista de caracteres \nQTC- Quantidade de caracteres \nALL - Mostrar todos caracteres\r\n\r\n'
    conexao_sock.sendall(str.encode(resp))
    linha1 = conexao_sock.recv(2048).decode()
    print('nome do requisao:',linha1)
    '''
    #GET /funcao HTTP/1.1
    linha1 = req.split('\n')[0]
    print('linha de requisicao: ',linha1)
    nome_op = linha1.split(' ')[1]
    print('nome do requisao: ',nome_op)
    nome_op = nome_op.strip('/').strip()
    '''
    linha1 = conexao_sock.recv(2048).decode()
    print('nome do requisao:',linha1)
    nome_op = linha1
    if nome_op == 'LC':
        linha_status = 'HTTP/1.1 200 OK \r\n'.encode()
        conexao_sock.send(linha_status)
        for caracter in code:
            num,nome,codigo = caracter.values()
            if num == 1:
                print('caracter: ',nome)
                check = nome
                conexao_sock.send(str.encode(check))
    elif nome_op == 'QTC':
        linha_status = 'HTTP/1.1 200 OK \r\n'.encode()
        conexao_sock.send(linha_status)
        cont = 0
        for caracter in code:
            num,nome,codigo = caracter.values()
            print('caracter: ',num,nome)
            cont = cont + 1
        let = str(cont)
        check = 'total: '+let+' caracteres\n'
        conexao_sock.send(str.encode(check))
    elif nome_op == 'ALL':
        linha_status = 'HTTP/1.1 200 OK \r\n'.encode()
        conexao_sock.send(linha_status)
        for caracter in code:
            num,nome,codigo = caracter.values()
            n = str(nome)
            no = str(num)
            cod = str(codigo)
            let = str(n+' '+no+' '+cod+'\n')
            print(let)
            check = let
            conexao_sock.send(str.encode(check))
    else:
        resposta = 'HTTP/1.1 404 Not Found\r\n opcao invalida \n'
        conexao_sock.send(resposta.encode())
        break
    conexao_sock.close()
